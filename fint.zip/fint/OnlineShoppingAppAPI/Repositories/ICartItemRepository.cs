﻿
using OnlineShoppingAppAPI.Entities;

namespace OnlineShoppingAppAPI.Repositories
{
    public interface ICartItemRepository
    {
        Task<List<CartItem>> GetAllCartItemsAsync();
        Task<CartItem> GetCartItemByIdAsync(string id);
        Task AddCartItemAsync(CartItem cartitem);
        Task UpdateCartItemAsync(CartItem cartitem);
        Task DeleteCartItemAsync(string id);
    }
}
