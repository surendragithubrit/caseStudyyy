﻿using OnlineShoppingAppAPI.Entities;

namespace OnlineShoppingAppAPI.Repositories
{
    public interface IProductRepository
    {
        Task Add(Product product);
        Task<Product> GetProductById(string productId);
        Task<List<Product>> GetAllProducts();
        Task<IEnumerable<Product>> GetItemsByFilterAsync(
        double? minPrice,
        double? maxPrice,
        string categoryName,
        string color,
      
        string brand,
        string size);
        Task Delete(string id);
        Task Update(Product product);


    }
}

