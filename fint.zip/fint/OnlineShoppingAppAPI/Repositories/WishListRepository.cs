﻿using OnlineShoppingAppAPI.Entities;

namespace OnlineShoppingAppAPI.Repositories
{
    public class WishListRepository : IWishListRepository
    {
        private readonly OnlineShopContext _context;
        private IConfiguration _configuration;

        public WishListRepository(OnlineShopContext context, IConfiguration configuration)
        {
            _context = context;
            _configuration = configuration;
        }

        public void Add(Wishlist wishlist)
        {
            _context.Wishlists.Add(wishlist);
            _context.SaveChanges();
        }

        public void Delete(string id)
        {
            var favorite = _context.Wishlists.Find(id);
            _context.Wishlists.Remove(favorite);
            _context.SaveChanges();
        }

        public List<Wishlist> GetAllFavorites()
        {
            return _context.Wishlists.ToList();
        }

        public Wishlist GetFavoriteById(string favoriteId)
        {
            var favorite = _context.Wishlists.Find(favoriteId);
            return favorite;
        }

        public void Update(Wishlist wishlist)
        {
            _context.Wishlists.Update(wishlist);
            _context.SaveChanges();
        }
    }
}
