﻿using Microsoft.EntityFrameworkCore;
using OnlineShoppingAppAPI.Entities;

namespace OnlineShoppingAppAPI.Repositories
{
    public class CartItemRepository : ICartItemRepository
    {
        private readonly OnlineShopContext _context;
        private readonly IConfiguration _configuration;

        public CartItemRepository(OnlineShopContext context, IConfiguration configuration)
        {
            _context = context;
            _configuration = configuration;
        }

        public async Task AddCartItemAsync(CartItem cartitem)
        {
            try
            {
                await _context.CartItems.AddAsync(cartitem);
                await _context.SaveChangesAsync();
            }catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
               
        }

        public async Task DeleteCartItemAsync(string id)
        {
            try
            {
                var item = await _context.CartItems.FindAsync(id);
                if (item != null)
                {
                    _context.CartItems.Remove(item);
                    await _context.SaveChangesAsync();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public async Task<List<CartItem>> GetAllCartItemsAsync()
        {
            try
            {
                return await _context.CartItems.ToListAsync();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);    
            }
        }

        public async Task<CartItem> GetCartItemByIdAsync(string id)
        {
            try
            {
                return await _context.CartItems.FindAsync(id);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        public async Task UpdateCartItemAsync(CartItem cartitem)
        {
            try
            {
                _context.CartItems.Update(cartitem);
                await _context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
    }
}
