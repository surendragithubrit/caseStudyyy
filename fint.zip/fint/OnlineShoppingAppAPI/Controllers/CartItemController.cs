﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using OnlineShoppingAppAPI.Entities;
using OnlineShoppingAppAPI.Repositories;
using System.Threading.Tasks;

namespace OnlineShoppingAppAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CartItemController : ControllerBase
    {
        private readonly ICartItemRepository _cartItemRepository;
        private readonly IConfiguration _configuration;

        public CartItemController(ICartItemRepository cartItemRepository, IConfiguration configuration)
        {
            _cartItemRepository = cartItemRepository;
            _configuration = configuration;
        }

        [HttpGet, Route("GetCartItems")]
        public async Task<IActionResult> GetAllAsync()
        {
            try
            {
                var items = await _cartItemRepository.GetAllCartItemsAsync();
                return StatusCode(200, items);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        [HttpGet, Route("GetItems/{id}")]
        public async Task<IActionResult> GetAsync([FromRoute] string id)
        {
            try
            {

                var cartItem = await _cartItemRepository.GetCartItemByIdAsync(id);
                if (cartItem != null)
                {
                    return StatusCode(200, cartItem);
                }
                else
                {
                    return StatusCode(404, "Invalid Id");
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        [HttpPost, Route("AddCartItem")]
        public async Task<IActionResult> AddAsync([FromBody] CartItem cartItem)
        {
            try
            {
                await _cartItemRepository.AddCartItemAsync(cartItem);
                return StatusCode(200, cartItem);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        [HttpPut, Route("EditCartItem")]
        public async Task<IActionResult> EditAsync([FromBody] CartItem cartItem)
        {
            try
            {
                await _cartItemRepository.UpdateCartItemAsync(cartItem);
                return StatusCode(200, cartItem);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        [HttpDelete, Route("DeleteCartItem")]
        public async Task<IActionResult> DeleteAsync([FromQuery] string id)
        {
            try
            {
                await _cartItemRepository.DeleteCartItemAsync(id);
                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }
    }
}
